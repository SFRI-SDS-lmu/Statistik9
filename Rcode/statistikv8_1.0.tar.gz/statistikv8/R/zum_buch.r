# zumbuch
# Hinweis: die Numerierungen der Funktionen können sich von den Numerierungen der
# Abbildungen und Tabellen im Buch unterscheiden.

#' @title Funktionen zum Buch
#' @description Erstelle die Politbarometerdaten 2013
#' @return Liste aus table-Objekt und data frame
#' \item{Absolut}{Absolute Häufigkeiten}
#' \item{Bedingt}{Bedingte Verteilung von Partei | Geschlecht}
#' @export
createPolitbarometer <- function(){
  partei <- c(rep(1,278), rep(2,174),	rep(3,39),
              rep(4,106), rep(5,57), rep(6,63 ),
              rep(1,281), rep(2,158),	rep(3,10),
              rep(4,72), rep(5,82), rep(6,29)
              )
  partei <- ordered(partei)
  levels(partei) <- c("CDU/CSU","SPD","FDP","Linke","Grüne","Sonstige")

  geschlecht <- c(rep(1,717), rep(2,632))
  geschlecht <- ordered(geschlecht)
  levels(geschlecht) <- c("Männer","Frauen")

  h <- table(geschlecht,partei)

  g <-data.frame(
    rbind(h["Männer",]/sum(h["Männer",]),
          h["Frauen",]/sum(h["Frauen",])),
    row.names=c("Männer","Frauen")
  )

  return(list(Absolut=h,
              Bedingt=g)
  )

}


#' @title Funktionen zum Buch
#' @description Erstelle die Kanzlerpräferenzdaten (Abbildung 1.1)
#' @export
#' @return data frame mit 2 Variablen: Kanzler versus Monat (Jan-Sep)
createKanzlerPraeferenz <- function(){
  kanzler <- c(rep(1,2261), rep(2,936),	rep(1,1096),rep(2,483), rep(1,2188), rep(2,1010),
              rep(1,2119), rep(2,927),	rep(1,1034), rep(2,455), rep(1,2164), rep(2,928),
              rep(1,2127), rep(2,987),	rep(1,3301), rep(2,1531), rep(1,3229), rep(2,1743)
  )
  kanzler <- ordered(kanzler)
  levels(kanzler) <- c("Angela Merkel","Peer Steinbrück")

  monat <- c(rep(1,3197), rep(2,1579), rep(3,3198),rep(4,3046),rep(5,1489),
             rep(6,3092), rep(7,3114), rep(8,4832), rep(9,4972))
  monat <- ordered(monat)
  levels(monat) <- c("Jan","Feb","Mär","Apr","Mai","Jun",
                     "Jul","Aug","Sep")

  #write.table( data.frame(kanzler,monat), file="kanzler.txt",row.names=F)

  return( data.frame(kanzler,monat))

}

#' @title Funktionen zum Buch
#' @description Erstelle Barplot (Abbildung 1.2 im Buch) für die
#' Variable "kanzler" der Kanzlerpräferenzdaten
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb1.1 <- function(){
  h<-createKanzlerPraeferenz()
  barplot( table(h$kanzler,h$monat),beside=T, ylim=c(0,4000),
           legend=T, args.legend=c(x="topleft"),
           xlab="Erhebungsmonat", ylab="Anzahl")
}

#' @title Funktionen zum Buch
#' @description Erstelle Zeitreihe (Abb. 1.3 im Buch) für die
#' BMW-Aktie
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb1.2 <- function(){
  require("tseries")

  bmw2 <- get.hist.quote(start="2000-01-01", end="2015-06-03", instrument="bmw.de",
                         quote="AdjClose")
  plot(bmw2, type="l",
       xlab="Zeitraum: 3.1.2000-3.6.2015", ylab="Tageskurse der BMW-Aktie")
}


#' @title Funktionen zum Buch
#' @description Erstelle Zeitreihe (Abb. 1.5 im Buch) für den
#' Geschäftsklimaindex
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb1.3 <- function(){
  require("tseries")

  gkidata <- data("ifo_zeitreihen", envir=environment())
  time <- ifo_zeitreihen$Zeit
  gki <- ifo_zeitreihen$Gewerbliche_Wirtschaft_Gki
  timeseries <- ts(gki, frequency=12, start=c(1991,1) )
  plot(timeseries,
       xlab="1991-2014", ylab="Geschäftsklimaindex")
}


#' @title Funktionen zum Buch
#' @description Erstelle die Tabelle 1.2 (Tabellenmietspiegel)
#' des Münchner Mietspiegels 2015: durchschnittliche Nettomiete/qm nach kategorialem Baualter
#' und kategorialer Wohnfläche
#' @export
#' @param () Keine Parameter
#' @return Liste mit 2 Objekten
#' \item{Stichprobenumfang}{Anzahl der Wohnungen in der jeweiligen Zelle der Tafel}
#' \item{Mittel.Nettomiete.per.qm}{Mittelwert der Wohnungen der jeweiligen Baujahr-Wohnflächenkombination}
#' @export
tab1.2 <- function(){

  data("mietspiegel2015", envir=environment())

  bj.cat <- cut(mietspiegel2015$bj, breaks=c(1900,1919, 1949, 1966, 1978, 1990,2015),
                labels=c("bis 1918", "1919 bis 48", "1949 bis 65", "1966 bis 77", "1978 bis 90",
                         "ab 1990"),
                right=FALSE,dig.lab=4)
  wfl.cat <- cut(mietspiegel2015$wfl, breaks=c(0,39,81,121,301),
                 labels=c("bis 38", "39-80", "81-120", "121 und mehr"),
                 right=FALSE,dig.lab=3)
  # Contingecny table
  cont.bj.wfl <- table(bj.cat,wfl.cat)

  daten <- data.frame(cbind(mietspiegel2015, bj.cat, wfl.cat))

  # Nettomiete/qm: Durchschnittliche Mittelwerte in der jeweilgen Kategorie
  nm.table <-by(daten$nmqm, list(daten[,14],daten[,15]), mean)
  nm.table <- matrix(nrow=6,ncol=4, data=nm.table)

  return( list(Stichprobenumfang=cont.bj.wfl,Mittel.Nettomiete.per.qm=nm.table) )
}

#' @title Funktionen zum Buch
#' @description Tabelle 1.3 mit den Politbarometerdaten 2013
#' @export
#' @return table-Objekt mit den bedingten relativen Häufigkeiten

tab1.3 <- function(){
  h <- createPolitbarometer()
  return(h$Bedingt)
}

#' @title Funktionen zum Buch
#' @description Erstelle die Häufigkeitstabellen (Abbildung 2.1 und Tabelle 2.1) für die
#' Variable Finanzierungsquelle der Münchner Absolventenstudie 2011
#' @export
#' @param () Keine Parameter
#' @return eine Liste mit 2 Table-Objekten
#' \item{absolut}{absolute Häufigkeiten}
#' \item{relativ}{relative Häufigkeiten}
abb2.1 <- function(){

  data("mas2011", envir=environment() )
  h <- table(mas2011$Finanzierungsquelle)
  return( list(absolut=h, relativ=h/sum(h)) )
}


#' @title Funktionen zum Buch
#' @description Erstelle die gruppierten Daten (Tabelle 2.2) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015 der 26 ausgewählten
#' Wohnungen ohne Warmwasser
#' @export
#' @param () Keine Parameter
#' @return Liste zweier table Objekte (absolute und relative Häufigkeiten)
#' @export
tab2.2 <- function(){

  data("mietspiegel2015", envir=environment())

  # Alle Wohnungen ohne zentrale Warmwasserversorgung
  ohne.ww <- subset(mietspiegel2015, ww0==1)

  h <- cut(ohne.ww$nm, breaks=c(0,200,400,600,800,1000), right=T)

  # Gruppieren
  return( list( absolut=table(h),relativ=table(h)/sum(table(h)) ) )
}


#' @title Funktionen zum Buch
#' @description Erstelle verschiedene Diagramme in einer Grafik (Abbildung 2.2) für
#' die Variable Statistik der Münchner Absolventenstudie 2011
#' @param () Keine Parameter
#' @return Grafik
#' @export

abb2.2 <- function(){

  data("mas2011", envir=environment())

  levels(mas2011$Statistik) <- c("gelegentl.", "häufig", "nie", "ständig")

  par(cex=1.5)

  abs.freq.Statistik <- table(mas2011$Statistik)
  percentlabels.Statistik.list<-
    c( "gelegentl.: 13","häufig: 9", "nie: 9", "ständig: 5")

  par(mfrow=c(2,2))
  # 2.2 (a)
  # Pie Chart from data frame with Appended Sample Sizes

  pie(abs.freq.Statistik,
      col=c("grey90","grey70","grey50","grey30"),
      labels=percentlabels.Statistik.list,
      main="(a)")

  # Barchart
  # 2.2 (b)
  barplot(table(mas2011$Statistik), ylab="Anzahl", main="(b)",
          ylim=c(0,14) )

  # 2.2 (c)
  default.mar <- par("mar")
  par("mar"=c(5, 6, 4, 2))
  barplot(table(mas2011$Statistik), horiz=TRUE, xlab="Anzahl", las=1,
          main="(c)", xlim=c(0,14))
  par("mar"=default.mar)

  # 2.2 (d)
  plot(mas2011$Statistik, width=c(1,1,1,1), space=10, main="(d)",
       ylim=c(0,14))

  par(mfrow=c(1,1))
  par(cex=1)

}


#' @title Funktionen zum Buch
#' @description Erstelle das Stabdiagramm (Abbildung 2.3) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, nur Wohnungen ohne
#' zentrale Warmwasserversorgung
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.3 <- function(){

  data("mietspiegel2015", envir=environment())

  # Alle Wohnungen ohne zentrale Warmwasserversorgung
  ohne.ww <- subset(mietspiegel2015, ww0==1)

  plot( sort(unique(ohne.ww$nm)), as.vector(table(ohne.ww$nm)),
        xlab=list("Nettomieten in Euro",cex=1.5),
        ylim=c(0,1.1), ylab="",type="h")

}

#' @title Funktionen zum Buch
#' @description Erstelle das Stabdiagramm (Abbildung 2.4) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, alle 3065 Wohnungen
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.4 <- function(){

  data("mietspiegel2015", envir=environment())

  plot( sort(unique(mietspiegel2015$nm)), as.vector(table(mietspiegel2015$nm)),
        xlab=list("Nettomieten in Euro", cex=1.5),
        ylim=c(0,40),
        ylab=list("Absolute Häufigkeit",cex=1.5),
        type="h")
}


#' @title Funktionen zum Buch
#' @description Erstelle das Stamm-Blatt-Diagramm (Abbildung 2.5) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, nur Wohnungen ohne
#' zentrale Warmwasserversorgung
#' @export
#' @param () Keine Parameter
#' @return Ausgabe in Konsole
#' @export
abb2.5 <- function(){

  data("mietspiegel2015", envir=environment())

  # Alle Wohnungen ohne zentrale Warmwasserversorgung
  nm.ohne.ww <- sort(subset(mietspiegel2015, ww0==1)$nm)

  stem(nm.ohne.ww)

}

#' @title Funktionen zum Buch
#' @description Erstelle das Stamm-Blatt-Diagramm (Abbildung 2.6) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, nur Wohnungen
#' >=80qm und <=100qm
#' @export
#' @param () Keine Parameter
#' @return Ausgabe in Konsole
#' @export
abb2.6 <- function(){

  data("mietspiegel2015", envir=environment())

  gross.daten <- subset(mietspiegel2015, (wfl>=80&wfl<=100))
  stem(gross.daten$nm,scale=2)
}

#' @title Funktionen zum Buch
#' @description Erstelle die Zeitreihe der Umlaufrenditen (Abb. 2.7)
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.7 <- function(){
  require(zoo)
  data(umlaufrenditen, envir=environment())
  umlauf2 <- read.zoo(umlaufrenditen, index=1, format="%Y-%m", FUN=as.yearmon)
  plot(umlauf2, ylim=c(0,12),type="l", ylab="Zins", xlab="")
}

#' @title Funktionen zum Buch
#' @description Erstelle das Stamm-Blatt-Diagramm der Umlaufrenditen (Abb. 2.8)
#' @export
#' @param () Keine Parameter
#' @return Konsole
#' @export
abb2.8 <- function(){
  data(umlaufrenditen, envir=environment())
  umlauf2 <- read.zoo(umlaufrenditen, index=1, format="%Y-%m", FUN=as.yearmon)
  stem(umlauf2, scale=2)
}


#' @title Funktionen zum Buch
#' @description Histogramm der Studiendauer (Abbildung 2.9) der Münchner
#' Absolventenstudie 2011
#' @param () Keine Parameter
#' @return Grafik
#' @export

abb2.9 <- function(){

  require("lattice")

  data("mas2011", envir=environment())

  hist <- histogram(~mas2011$Studiendauer,
            xlab=list("Studiendauer in Semestern",cex=1.5),
            breaks=c(8,10,12,14,16,18,20),
            ylab=list("Anteil in Prozent",cex=1.5),
            col="grey90",
            scales=list(cex=1.5))
  print(hist)
}


#' @title Funktionen zum Buch
#' @description Erstelle das Histogramm (Abbildung 2.10) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, nur Wohnungen ohne
#' zentrale Warmwasserversorgung
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.10 <- function(){

  require("lattice")

  data("mietspiegel2015", envir=environment())

  # Alle Wohnungen ohne zentrale Warmwasserversorgung
  nm.ohne.ww <- sort(subset(mietspiegel2015, ww0==1)$nm)

  hist <- histogram(~nm.ohne.ww, xlab=list("Nettomiete in Euro",cex=1.5),
            breaks=c(0,200,400,600,800,1000),
            ylab=list("Anteile in Prozent",cex=1.5),
            scales=list(cex=1.5),
            col="grey90")
  print(hist)
}


#' @title Funktionen zum Buch
#' @description Erstelle das Histogramm (Abbildung 2.11) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, alle 3065 Wohnungen
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.11 <- function(){

  require("lattice")

  data("mietspiegel2015", envir=environment())
  hist <- histogram(~mietspiegel2015$nm,
            breaks=seq(from=0,to=6000,by=100),
            xlab=list(label="Nettomiete in Euro",cex=1.5),
            ylab=list("Anteile in Prozent", cex=1.5), col="grey90",
            type="percent",
            scales=list(cex=1.5))
  print(hist)
}

#' @title Funktionen zum Buch
#' @description Erstelle das geschichtete Histogramm (Abbildung 2.12) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, alle 3065 Wohnungen
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.12 <- function(){

  require("lattice")


  data("mietspiegel2015", envir=environment())

  wfl.cat <- cut(mietspiegel2015$wfl, breaks=c(0,39,81,121,301),
                 labels=c("bis 38", "39-80", "81-120", "121 und mehr"),
                 right=FALSE,dig.lab=3)
  hist <- histogram(~mietspiegel2015$nm | wfl.cat,
            breaks=seq(from=0,to=6000,by=100),
            xlab=list(label="Nettomiete in Euro",cex=1.5),
            ylab=list("Anteile in Prozent", cex=1.5), col="grey90",
            type="percent",
            scales=list(cex=1.5),
            layout=c(1,4))
  print(hist)
}

#' @title Funktionen zum Buch
#' @description Erstelle das Histogramm (Abbildung 2.13) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, Wohnungen >120qm
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.13 <- function(){

  require("lattice")

  data("mietspiegel2015", envir=environment())
  sehr.grosse.wfl <- subset(mietspiegel2015, wfl>120)
  hist <- histogram(~sehr.grosse.wfl$nm,
            breaks=seq(from=0,to=6000,by=50),
            xlab=list(label="Nettomiete in Euro",cex=1.5),
            ylab=list("Anteile in Prozent", cex=1.5), col="grey90",
            type="percent",
            scales=list(cex=1.5))
  print(hist)
}

#' @title Funktionen zum Buch
#' @description Erstelle das Histogramm (Abbildung 2.14) für die
#' Münchner Rück Aktie (Renditen=log returns)
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.14 <- function(){

  require("lattice")
  require("tseries")


  munichre2 <- get.hist.quote(start="2000-01-01", end="2015-06-03",instrument="muv2.de", quote="AdjClose")
  r.munichre2 <- diff(log(munichre2$Adjusted))
  hist <- histogram(data.frame(r.munichre2)$r.munichre2,
            xlab=list("Rendite der Munich RE-Aktie",cex=1.5),col="grey90",
            ylab=list("Anteil in Prozent",cex=1.5),
            breaks=c(-0.19,-0.14,-0.09,-0.04,0.01,0.06,0.11,0.16,0.21,0.26),
            scales=list(cex=1.5))
  print(hist)
}

#' @title Funktionen zum Buch
#' @description Erstelle das Histogramm (Abbildung 2.15) für die
#' Münchner Rück Aktie (Renditen=log returns), feinere Klasseneinteilung als
#' bei Abb. 2.14
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.15 <- function(){

  require("lattice")
  require("tseries")


  munichre2 <- get.hist.quote(start="2000-01-01", end="2015-06-03",instrument="muv2.de", quote="AdjClose")
  r.munichre2 <- diff(log(munichre2$Adjusted))
  hist <- histogram(data.frame(r.munichre2)$r.munichre2,
            xlab=list("Rendite der Munich RE-Aktie",cex=1.5),col="grey90",
            ylab=list("Anteil in Prozent",cex=1.5),
            breaks=20,
            scales=list(cex=1.5))
  print(hist)
}

# Abbildung 2.16 nicht reproduzierbar

#' @title Funktionen zum Buch
#' @description Erstelle das Histogramm der Umlaufrenditen (Abb. 2.17)
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.17 <- function(){

  require("lattice")

  data(umlaufrenditen, envir=environment())
  hist <- histogram(umlaufrenditen$BBK01.WU0017,
            breaks=c(0,0.5,1,1.5,2,2.5,3,3.5,4,4.5,5,5.5,6,6.5,
                     7,7.5,8,8.5,9,9.5,10,10.5,11,11.5,12),
            col="grey90",
            xlab=list("Umlaufrendite in Prozent",cex=1.5),
            ylab=list("Anteil in Prozent",cex=1.5),
            scales=list(cex=1.5))
  print(hist)
}

# Abbildung 2.18: ohne Daten



#' @title Funktionen zum Buch
#' @description Empirische Verteilungsfunktion der Studiendauer (Abbildung 2.19)
#' der Münchner Absolventenstudie 2011
#' @param () Keine Parameter
#' @return Grafik
#' @export

abb2.19 <- function(){

  data("mas2011", envir=environment())
  edf <- ecdf(mas2011$Studiendauer)
  plot(edf,verticals=TRUE,main="",xlab="Studiendauer", ylab="F(x)")
}

#' @title Funktionen zum Buch
#' @description Erstelle die empirische Verteilungsfunktion (Abbildung 2.20) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, nur Wohnungen ohne
#' zentrale Warmwasserversorgung
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.20 <- function(){

  data("mietspiegel2015", envir=environment())
  # Alle Wohnungen ohne zentrale Warmwasserversorgung
  nm.ohne.ww <- sort(subset(mietspiegel2015, ww0==1)$nm)
  edf <- ecdf(nm.ohne.ww)
  #par(cex.lab=1.5)
  plot(edf,verticals=TRUE,main="",xlab="Nettomiete in Euro", ylab="F(x)")
  #par(cex.lab=1)
}


#' @title Funktionen zum Buch
#' @description Erstelle die empirische Verteilungsfunktion (Abbildung 2.21) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, alle 3065 Wohnungen
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.21 <- function(){

  data("mietspiegel2015", envir=environment())
  edf.alle <- ecdf(mietspiegel2015$nm)
  #par(cex.lab=1.5)
  plot(edf.alle,verticals=TRUE,main="",xlab="Nettomiete in Euro", ylab="F(x)")
  #par(cex.lab=1)
}

#' @title Funktionen zum Buch
#' @description Erstelle die empirische Verteilungsfunktion (Abbildung 2.22) für die
#' Tagesrenditen der BMW-Aktie
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.22 <- function(){
  require("tseries")

  bmw2 <- get.hist.quote(start="2000-01-01", end="2015-06-03", instrument="bmw.de", quote="AdjClose")
  r.bmw2 <- diff(log(bmw2$Adjusted))
  ecdf.bmw.returns <- ecdf( as.vector(r.bmw2))
  plot(ecdf.bmw.returns, verticals=TRUE,main="",
       xlab="Rendite der BMW-Aktie", ylab="F(x)")
}


#' @title Funktionen zum Buch
#' @description Berechnungen (Beipsiel 2.13) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, nur Wohnungen ohne
#' zentrale Warmwasserversorgung
#' @export
#' @param () Keine Parameter
#' @return Konsole und Mittelwert der Nettomieten, sowie geschichtet
#' \item{ohne.ww}{Mittelwert der Nettomiete der Wohnungen ohne zentrale Warmwasserversorgung}
#' \item{alle}{Mittelwert aller Nettomieten}
#' \item{geschichtet}{Mittelwert der Nettomieten aller Wohnungen,
#' geschichtet nach kategorialer Wohnfläche}
#' @export
bsp2.13 <- function(){

  data("mietspiegel2015", envir=environment())
  # Alle Wohnungen ohne zentrale Warmwasserversorgung
  nm.ohne.ww <- sort(subset(mietspiegel2015, ww0==1)$nm)
  # Beispiel 2.13 Mittewert der 26 Nettomieten der Wohnungen ohne WW
  xquer.ohne.ww <- mean(nm.ohne.ww)
  cat("Mittelwert der ", length(nm.ohne.ww), " Wohnungen ohne WW: ",
      xquer.ohne.ww, "\n")

  # Mittlere Nettomiete aller Wohnungen
  xquer.alle <- mean(mietspiegel2015$nm)
  cat("Mittelwert aller ", length(mietspiegel2015$nm), " Wohnungen: ",
      xquer.alle, "\n")

  # Alle Wohnungen, geschichtet nach kategorialer Größe
  wfl.cat <- cut(mietspiegel2015$wfl, breaks=c(0,39,81,121,301),
                 labels=c("bis 38", "39-80", "81-120", "121 und mehr"),
                 right=FALSE,dig.lab=3)
  means.wfl.cat <- tapply(mietspiegel2015$nm, wfl.cat, mean)
  print(means.wfl.cat)


  return(list(ohne.ww=xquer.ohne.ww,alle=xquer.alle, geschichtet=means.wfl.cat))
}


#' @title Funktionen zum Buch
#' @description Berechnungen (Beispiel 2.14) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, nur Wohnungen ohne
#' zentrale Warmwasserversorgung
#' @export
#' @param () Keine Parameter
#' @return Mittelwerte der Nettomieten/qm, geschichtet und total
#' \item{baujahr}{nach Baujahr (kategorial)}
#' \item{wohnflaeche}{nach Wohnflaeche (kategorial)}
#' \item{total}{Gesamtmittel Nettomiete pro qm}
#' @export
bsp2.14 <- function(){

  data("mietspiegel2015", envir=environment())

  # Alle Wohnungen, geschichtet nach kategorialer Größe
  wfl.cat <- cut(mietspiegel2015$wfl, breaks=c(0,39,81,121,301),
                 labels=c("bis 38", "39-80", "81-120", "121 und mehr"),
                 right=FALSE,dig.lab=3)
  # Baujahr kategorisiert
  bj.cat <- cut(mietspiegel2015$bj, breaks=c(1900,1919, 1949, 1966, 1978, 1990,2015),
                labels=c("bis 1918", "1919 bis 48", "1949 bis 65", "1966 bis 77", "1978 bis 90",
                         "ab 1990"),
                right=FALSE,dig.lab=4)
  # Mittlere Nettomieten/qm gestaffelt nach kategrorialer Größe
  means.wfl.cat <- tapply(mietspiegel2015$nmqm, wfl.cat, mean)
  print(means.wfl.cat)
  # alternativ via split
  daten.wfl.cat <- split(mietspiegel2015, wfl.cat)
  sample.sizes.wfl.cat <- sapply(daten.wfl.cat, nrow )
  print("Sample sizes WFL.cat: ")
  print(sample.sizes.wfl.cat)

  # dito: Daten nach kategorialem Baujahr
  daten.bj.cat <- split(mietspiegel2015, bj.cat)
  sample.sizes.bj.cat <- sapply(daten.bj.cat, nrow )
  means.bj.cat <- tapply(mietspiegel2015$nmqm, bj.cat, mean)
  print(means.bj.cat)
  print("Sample sizes BJ.cat: ")
  print(sample.sizes.bj.cat)

  # Alle Wohnungen: Mittelwert von nm/qm
  mean.alle.nmqm <- mean(mietspiegel2015$nmqm)
  print(mean.alle.nmqm)

  return(list(baujahr=means.bj.cat,wohnflaeche=means.wfl.cat,total=mean.alle.nmqm))
}

#' @title Funktionen zum Buch
#' @description Berechnungen (Beipsiel 2.13) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, nur Wohnungen ohne
#' zentrale Warmwasserversorgung, Ausreisserempfindlichkeit des arithmetischen Mittels
#' @export
#' @param maximum Liste von hypothetischen Maxima
#' @return Konsole
#' @export
bsp2.13a <- function(maximum=c(940,1300)){

  data("mietspiegel2015", envir=environment())
  # Alle Wohnungen ohne zentrale Warmwasserversorgung
  nm.ohne.ww <- sort(subset(mietspiegel2015, ww0==1)$nm)
  # hypothetische Annahmen, um Unrobustheit des arithmetischen Mittels zu zeigen
  annahme <- vector(mode="numeric", length=length(maximum))
  for ( i in 1:length(maximum)){
    hypo<- nm.ohne.ww
    hypo[26] <- maximum[i]
    annahme[i] <- mean(hypo)
  }
  return(annahme)
}

#' @title Funktionen zum Buch
#' @description Berechnungen (nach Beispiel 2.14 und 2.15) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, nur Wohnungen ohne
#' zentrale Warmwasserversorgung, sowie alle Wohnungen und geschichtet
#' nach Groesse, Median
#' @export
#' @param () Keine
#' @return Liste der Mediane
#' @export
bsp2.2b <- function(){

  data("mietspiegel2015", envir=environment())
  # Alle Wohnungen ohne zentrale Warmwasserversorgung
  nm.ohne.ww <- sort(subset(mietspiegel2015, ww0==1)$nm)

  # Alle Wohnungen, geschichtet nach kategorialer Größe
  wfl.cat <- cut(mietspiegel2015$wfl, breaks=c(0,39,81,121,301),
                 labels=c("bis 38", "39-80", "81-120", "121 und mehr"),
                 right=FALSE,dig.lab=3)
  median.wfl.cat <- tapply(mietspiegel2015$nm, wfl.cat, median)

  return(list(median.ohne.ww=median(nm.ohne.ww),
               median.alle=median(mietspiegel2015$nm),
               median.geschichtet=median.wfl.cat))
}

#' @title Funktionen zum Buch
#' @description Berechnungen (Beispiel 2.16 im Buch) für die
#' Muenchner Absolventenstudie 2011. Modus und gruppierter Modus
#' @export
#' @param () Keine
#' @return Liste der Modus und Mittelwerte, gruppiert und ungruppiert
#' @export

bsp2.15 <- function(){


  data("mas2011", envir=environment())
  h <- table(mas2011$Studiendauer)
  modus <- h[which.max(h)]

  hcat <- cut(mas2011$Studiendauer,breaks=c(8,10,12,14,16,18,20),right=T)
  gruppierter.modus <-
    10 + 2*(0.5 -0.11111111) / 0.58333333

  mittel <- mean(mas2011$Studiendauer)

  mittel.gruppiert <- 9*0.111 + 11*0.583 + 13*0.222 + 15*0.055 + 17*0.0 + 19*0.028


  return(list(Modus=modus, gruppierter.Modus=gruppierter.modus,
              Mittel=mittel,
              gruppiertes.Mittel=mittel.gruppiert))
}

#' @title Funktionen zum Buch
#' @description Berechnungen Tabelle 2.3. (links-,rechtssteil, symmetrisch)
#' @export
#' @param () Keine
#' @return Liste der Modus, Mediane und Mittelwerte
#' @export
tab2.3 <- function(){

  s1 <- c(rep(1,8),rep(2,10),rep(3,8),rep(4,6),rep(5,5),rep(6,4),rep(7,2),
          rep(8,2),rep(9,1) )
  s2 <- c(rep(1,1),rep(2,2),rep(3,4),rep(4,8),rep(5,10),rep(6,8),rep(7,4),
          rep(8,2),rep(9,1) )
  s3 <- c(rep(1,1),rep(2,2),rep(3,2),rep(4,4),rep(5,5),rep(6,6),rep(7,8),
          rep(8,10),rep(9,8) )

  return(list(
    mittel.s1=mean(s1),
    mittel.s2=mean(s2),
    mittel.s3=mean(s3),
    median.s1=median(s1),
    median.s2=median(s2),
    median.s3=median(s3),
    modus.s1=which.max(table(s1)),
    modus.s2=which.max(table(s2)),
    modus.s3=which.max(table(s3))
  ))
}

#' @title Funktionen zum Buch
#' @description Berechnungen geometrisches Mittel (Beispiel 2.17 im Buch)
#' @export
#' @param () Keine
#' @return geometrisches Mittel
#' @export
bsp2.16 <- function(){
  xgeom <-
    (0.9761*0.9807*0.9823*0.9865*0.9919*1.0032*
     1.0010*1.0043*1.0387*1.0403*1.0115)^(1/11)
  return(xgeom)
}

#' @title Funktionen zum Buch
#' @description Abbildung 2.23 im Buch für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, nur Wohnungen ohne
#' zentrale Warmwasserversorgung, sowie alle Wohnungen und geschichtet
#' nach Groesse, Median
#' @export
#' @param () Keine
#' @return Grafik
#' @export
abb2.23 <- function(){

  data("mietspiegel2015", envir=environment())
  # Alle Wohnungen ohne zentrale Warmwasserversorgung
  nm.ohne.ww <- sort(subset(mietspiegel2015, ww0==1)$nm)

  edf.26 <- ecdf(nm.ohne.ww)
  plot(edf.26,
       verticals=TRUE,
       main="",
       xlab=list("Nettomiete in Euro",cex=1.0),
       ylab=list("F(x)",cex=1.0),
       do.points=FALSE)
  arrows(0,0.25, 315.69, 0.25)
  arrows(315.69,0.25, 315.69,0)
  arrows(0,0.5, 498.16, 0.5)
  arrows(498.16,0.5, 498.16, 0.0)
  arrows(0,0.75, 650, 0.75)
  arrows(650,0.75, 650, 0)
  text(200,0.3,"unteres Quartil \n = 315.69", adj=0.4, cex=0.7)
  text(200,0.55,"Median \n = 498.16", adj=0.4, cex=0.7)
  text(200,0.8,"oberes Quartil \n = 650.00", adj=0.4, cex=0.7)
}

#' @title Funktionen zum Buch
#' @description Abbildung 2.24, Variable Nettomiete des Münchner Mietspiegels 2015,
#' Wohnungen geschichtet nach Groesse, Boxplots
#' @export
#' @param () Keine
#' @return Grafik
#' @export
abb2.24 <- function(){

  require(lattice)

  data("mietspiegel2015", envir=environment())

  # Alle Wohnungen, geschichtet nach kategorialer Größe
  wfl.cat <- cut(mietspiegel2015$wfl, breaks=c(0,39,81,121,301),
                 labels=c("bis 38", "39-80", "81-120", "121 und mehr"),
                 right=FALSE,dig.lab=3)
  bp <- bwplot(~mietspiegel2015$nm | wfl.cat,
         xlab=list(label="Nettomiete in Euro",cex=1.5),
         scales=list(cex=1.5))
  print(bp)
}

#' @title Funktionen zum Buch
#' @description Erstelle den Boxplot (Abbildung 2.25) für die
#' Münchner Rück Aktie (Renditen=log returns)
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.25 <- function(){

  require("lattice")
  require("tseries")

  munichre2 <- get.hist.quote(start="2000-01-01", end="2015-06-03",instrument="muv2.de", quote="AdjClose")
  r.munichre2 <- diff(log(munichre2$Adjusted))
  bp <- bwplot(~r.munichre2,
         xlab=list(label="Rendite der Munich RE-Aktie",cex=1.5),
         scales=list(cex=1.5),
         xlim=c(-0.21,+0.21))
  print(bp)
}


#' @title Funktionen zum Buch
#' @description Erstelle den Boxplot (Abbildung 2.26) für die
#' Umlaufrenditen
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.26 <- function(){

  data("umlaufrenditen",envir=environment())

  require("lattice")
  bp <- bwplot(~umlaufrenditen$BBK01.WU0017,
         xlab=list("Umlaufrendite", cex=1.5),
         scales=list(cex=1.5))
  print(bp)
}


#' @title Funktionen zum Buch
#' @description Berechnungen (Beispiel 2.22) für die
#' Variable Nettomiete und Nettomiete/qm des Münchner Mietspiegels 2015,
#' nur Wohnungen ohne zentrale Warmwasserversorgung, sowie alle Wohnungen
#' und geschichtet nach Groesse
#' @export
#' @param () Keine
#' @return Liste der Ergebnisse
#' @export
bsp2.21 <- function(){

  data("mietspiegel2015", envir=environment())
  # Alle Wohnungen ohne zentrale Warmwasserversorgung
  nm.ohne.ww <- sort(subset(mietspiegel2015, ww0==1)$nm)
  wfl.cat <- cut(mietspiegel2015$wfl, breaks=c(0,39,81,121,301),
                 labels=c("bis 38", "39-80", "81-120", "121 und mehr"),
                 right=FALSE,dig.lab=3)

  # Varianz mit Verschiebungssatz, nur 26 Wohnungen ohne WW
  (1/26) *sum(nm.ohne.ww^2) - mean(nm.ohne.ww)^2
  var.hand <- (1/26) *sum(nm.ohne.ww^2) - 520.11^2
  var.exakt <- var(nm.ohne.ww) * (25/26)

  # Alle Wohnungen, nm/qm
  stdabw.alle <- sqrt( var(mietspiegel2015$nmqm) *
                         (length(mietspiegel2015$nmqm-1)/
                            length(mietspiegel2015$nmqm)) )

  # alle, nm
  stdabwnm.alle <- sqrt( var(mietspiegel2015$nm) *
                           (length(mietspiegel2015$nm-1)/
                              length(mietspiegel2015$nm)) )

  # geschichtet nach WFL, nm/qm
  stdabw.wfl.cat <- sqrt( tapply(mietspiegel2015$nmqm,wfl.cat, var) *3064/3065 )

  # dito, nm direkt
  stdabwnm.wfl.cat <- sqrt( tapply(mietspiegel2015$nm, wfl.cat, var) *3064/3065 )

  # per Hand, geschichtet, Gesamtvarianz nm/qm
  var.alle.nmqm <-
    (1/3065)* (
      226*2.43^2 + 1893*2.57^2 + 835*2.67^2 +
        111*3.05^2)
  + (1/3065)*(226*(12.85 - 10.73)^2 +
                1893*(10.58 - 10.73)^2 +
                835*(10.52 - 10.73)^2 +
                111*(10.51-10.73)^2
  )

  return(list(
    s2nm.ohne.ww.hand=var.hand,
    s2nm.ohne.ww.exakt=var.exakt,
    snm.ohne.ww.hand=sqrt(var.hand),
    snm.ohne.ww.exakt=sqrt(var.exakt),
    snm.gesamt = stdabwnm.alle,
    snmqm.gesamt = stdabw.alle,
    snm.geschichtet =   stdabwnm.wfl.cat,
    snmqm.geschichtet =   stdabw.wfl.cat,
    var.gesamt.per.hand.aus.schichten =  var.alle.nmqm
  ))

}

#' @title Funktionen zum Buch
#' @description Berechne die Varianz für die
#' Münchner Rück Aktie (Beispiel 2.23)
#' @export
#' @param () Keine Parameter
#' @return Varianz
#' @export
bsp2.22 <- function(){
  require("tseries")

  munichre2 <- get.hist.quote(start="2000-01-01", end="2015-06-03",instrument="muv2.de", quote="AdjClose")
  r.munichre2 <- diff(log(munichre2$Adjusted))
  return( var(r.munichre2)*( (length(r.munichre2)-1)/length(r.munichre2) ) )
}

#' @title Funktionen zum Buch
#' @description Berechnungen (Beispiel 2.24) für die
#' Variable Nettomiete/qm des Münchner Mietspiegels 2015,
#' geschichtet nach Groesse
#' @export
#' @param () Keine
#' @return Liste der Variationskoffizienten (per Hand)
#' @export
bsp2.23 <- function(){
  v <- c(2.43/12.85, 2.57/10.58, 2.67/10.52, 3.05/10.51)
  return(v)
}


# Wölbung
curtosis <- function(x){
  n <- length(x)
  mx <- mean(x)
  m4 <- 1/n * sum( (x-mx)^4 )
  s4 <- ( var(x)*((n-1)/n) )^2
  m4/s4-3
}

#' @title Funktionen zum Buch
#' @description Berechne Schiefe und Kurtosis für die
#' Münchner Rück Aktie und die BMW-Aktie (Beispiel 2.25), Tageswerte (default anderer Zeitraum wie im Buch!)
#' @export
#' @param () Keine Parameter
#' @return Liste der Kennzahlen
#' @export
bsp2.24.daily <- function(){
  require("tseries")
  require("moments")
  # daily
  munichre2 <- get.hist.quote(start="2000-01-01", end="2015-06-03",instrument="muv2.de", quote="AdjClose")
  r.munichre2 <- diff(log(munichre2$Adjusted))

  bmw2 <- get.hist.quote(start="2000-01-01", end="2015-06-03", instrument="bmw.de", quote="AdjClose")
  r.bmw2 <- diff(log(bmw2$Adjusted))

  # Schiefe
  qc.mr  <- ( (quantile(r.munichre2,prob=0.75)-median(r.munichre2) ) -
                (median(r.munichre2) - quantile(r.munichre2,prob=0.25)) ) /
    (quantile(r.munichre2,prob=0.75)-quantile(r.munichre2,prob=0.25) )

  qc.bmw <- ( (quantile(r.bmw2,prob=0.75)-median(r.bmw2) ) -
                (median(r.bmw2) - quantile(r.bmw2,prob=0.25)) ) /
    (quantile(r.bmw2,prob=0.75)-quantile(r.bmw2,prob=0.25) )
  smr <- skewness(r.munichre2) #, method="moment")
  sbmw <- skewness(r.bmw2) #, method="moment")

  cmr <- kurtosis(r.munichre2) -3
  cbmw <- kurtosis(r.bmw2) -3

  print(skewness(r.munichre2, na.rm=T))
  print(kurtosis(r.munichre2, na.rm=T)-3)

  return(list(
    Quartilskoeff.MR.direkt=qc.mr,
    Schiefe.MR.rfunktion=smr,
    Kurtosis.MR = cmr,
    Quartilskoeff.BMW.direkt=qc.bmw,
    Schiefe.BMW.rfunktion=sbmw,
    Kurtosis.BMW = cbmw
  ))

}


#' @title Funktionen zum Buch
#' @description Berechne Schiefe und Kurtosis für die
#' Münchner Rück Aktie und die BMW-Aktie (Beispiel 2.25), Monatswerte (default anderer Zeitraum wie im Buch!)
#' @export
#' @param () Keine Parameter
#' @return Liste der Kennzahlen
#' @export
bsp2.24.monthly <- function(start="2000-01-01", end="2015-06-03"){
  require("tseries")
  require("moments")
  # monthly
  munichre2 <- get.hist.quote(start=start,
                              end=end,
                              instrument="muv2.de",
                              quote="AdjClose",
                              compression="m")
  r.munichre2 <- diff(log(munichre2$Adjusted))

  bmw2 <- get.hist.quote(start=start,
                         end=end,
                         instrument="bmw.de",
                         quote="AdjClose",
                         compression="m")
  r.bmw2 <- diff(log(bmw2$Adjusted))

  # Schiefe
  qc.mr  <- ( (quantile(r.munichre2,prob=0.75)-median(r.munichre2) ) -
                (median(r.munichre2) - quantile(r.munichre2,prob=0.25)) ) /
    (quantile(r.munichre2,prob=0.75)-quantile(r.munichre2,prob=0.25) )

  qc.bmw <- ( (quantile(r.bmw2,prob=0.75)-median(r.bmw2) ) -
                (median(r.bmw2) - quantile(r.bmw2,prob=0.25)) ) /
    (quantile(r.bmw2,prob=0.75)-quantile(r.bmw2,prob=0.25) )
  smr <- skewness(r.munichre2) #, method="moment")
  sbmw <- skewness(r.bmw2) #, method="moment")

  cmr <- kurtosis(r.munichre2) -3
  cbmw <- kurtosis(r.bmw2) -3

  print(skewness(r.munichre2, na.rm=T))
  print(kurtosis(r.munichre2, na.rm=T)-3)

  return(list(
    mr.data=munichre2,
    bmw.data=bmw2,
    mr.monthly.returns=r.munichre2,
    bmw.monthly.returns=r.bmw2,
    Quartilskoeff.MR.direkt=qc.mr,
    Schiefe.MR.rfunktion=smr,
    Kurtosis.MR = cmr,
    Quartilskoeff.BMW.direkt=qc.bmw,
    Schiefe.BMW.rfunktion=sbmw,
    Kurtosis.BMW = cbmw
  ))
}

#' @title Funktionen zum Buch
#' @description Berechne Histogramm
#' Münchner Rück Aktie (Abbildung 2.31 im Buch), Monatswerte
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.30 <- function(){
  require("tseries")
  require("lattice")
  # daily
  munichre2 <- get.hist.quote(start="2000-01-01",
                              end="2015-06-03",
                              instrument="muv2.de",
                              quote="AdjClose",
                              compression="m")
  r.munichre2 <- diff(log(munichre2$Adjusted))

  m <- mean(r.munichre2)
  s <- sd(r.munichre2)


  hist <- histogram(data.frame(r.munichre2)$r.munichre2,
            xlab=list("Monatliche Rendite der Munich RE-Aktie",cex=1.5),
            col="grey90",
            ylab=list("Dichte",cex=1.5),
            breaks=c(-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,
                       0.0,
                       0.1,0.2,0.3,0.4,0.5,0.6,0.7),
            type="density",
            scales=list(cex=1.5),
            panel = function(x, ...) {
              panel.histogram(x, ...)
              panel.mathdensity(dmath = dnorm, col = "black",
                                args = list(mean=m,sd=s),n=100)
            }
            )
  print(hist)
}

#' @title Funktionen zum Buch
#' @description Berechne GINI Koeffizient, Tabelle 2.7, Grafik 2.29, Beispiel 2.31
#' @export
#' @param () Keine Parameter
#' @return Koeffizient
#' @export
bsp2.7 <- function(){

  verkaeufe <- c(40.2, 41.4, 46.1, 50.4, 59.1, 61.1, 75.0, 95.0, 192.7, 314.2)
  summe <- sum(verkaeufe)
  ah_div_summe <- verkaeufe / summe
  vj <- cumsum(ah_div_summe)
  print(summe)
  print( cbind(ah_div_summe,vj))

  # Gini-Koeffizient
  G <- 2*sum((1:10)*verkaeufe) / (10*sum(verkaeufe)) - 11/10

  # Herfindahl
  H <- sum( ah_div_summe^2)

  # Konzentrationsrate
  CR <- cumsum( sort(ah_div_summe, decreasing=TRUE ))

  return( list(summe=summe,aihi=ah_div_summe, vj=vj, Gini=G, Herfindahl=H,
               Konzentrationsraten=CR))
}

#' @title Funktionen zum Buch
#' @description Berechne GINI Smartphones (Abbildung 2.29)
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.28 <- function(){
  verkaeufe <- c(40.2, 41.4, 46.1, 50.4, 59.1, 61.1, 75.0, 95.0, 192.7, 314.2)
  summe <- sum(verkaeufe)
  ah_div_summe <- verkaeufe / summe
  vj <- cumsum(ah_div_summe)
  uj <- (1:10) / 10
  plot(c(0,uj),c(0,vj),type="o", xlim=c(0,1), ylim=c(0,1), xlab="", ylab="",
       xaxs="i", yaxs="i")
  abline(a=0,b=1)
}

#' @title Funktionen zum Buch
#' @description Berechne Dichte symmetrisch, Abbildung 2.33a
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.32a <- function(){
    x <- seq(from=0, to=8, by=0.001)
    y <- dnorm(x, mean=4, sd=1)
    plot(x,y, type="l",
         xlab=list("symmetrisch",cex=1.5),
         ylab=list("Dichte  f(x)",cex=1.5), ylim=c(0,0.5))
}

#' @title Funktionen zum Buch
#' @description Berechne Dichte rechtsschief, Abbildung 2.33b
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.32b <- function(){
  x <- seq(from=0, to=8, by=0.001)
  y <- dgamma(x, shape=1.6, scale=20/16)
  plot(x,y, type="l",
       xlab=list("rechtsschief",cex=1.5),
       ylab=list("Dichte  f(x)",cex=1.5), ylim=c(0,0.5))
}

#' @title Funktionen zum Buch
#' @description Berechne Dichte unimodal, Abbildung 2.33c
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.32c <- function(){
  x <- seq(from=-4, to=4, by=0.001)
  y <- dnorm(x, mean=0, sd=1)
  plot(x,y, type="l",
       xlab=list("unimodal",cex=1.5),
       ylab=list("Dichte  f(x)",cex=1.5), ylim=c(0,0.5))
}

#' @title Funktionen zum Buch
#' @description Berechne Dichte bimodal, Abbildung 2.33d
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.32d <- function(){
  x <- seq(from=-4, to=4, by=0.001)
  y <- 0.8*dnorm(x, mean=-1, sd=0.8) + 0.2*dnorm(x,mean=1,sd=0.3)
  plot(x,y, type="l",
       xlab=list("bimodal",cex=1.5),
       ylab=list("Dichte  f(x)",cex=1.5), ylim=c(0,0.5))
}

#' @title Funktionen zum Buch
#' @description Berechne Dichte multimodal, Abbildung 2.33e
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.32e <- function(){
  x <- seq(from=-4, to=4, by=0.001)
  y <- 0.2*dnorm(x, mean=-1.8, sd=0.25) +
       0.6*dnorm(x,mean=0,sd=0.5)+
       0.2*dnorm(x,mean=1.8,sd=0.4)
  plot(x,y, type="l",
       xlab=list("multimodal",cex=1.5),
       ylab=list("Dichte  f(x)",cex=1.5), ylim=c(0,0.5))
}


#' @title Funktionen zum Buch
#' @description Berechne Histogramm und Dichtekurven, Abbildung 2.35a
#' Nettomiete in Euro
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.34a <- function(){
  require("lattice")
  # daily
  data("mietspiegel2015", envir=environment())

  hist <- histogram(mietspiegel2015$nm,
            xlab=list("Nettomiete in Euro",cex=1.5),col="grey90",
            ylab=list("Dichte",cex=1.5),
            type="density",
            breaks=seq(from=0,to=6000,by=200),
            scales=list(cex=1.5),
            panel = function(x, ...) {
              panel.histogram(x, ...)
              panel.densityplot(x, col="black",plot.points=FALSE)
              #panel.mathdensity(dmath = dnorm, col = "black",
              #                 args = list(mean=
              #                                mean(mietspiegel2015$nm),
              #                                sd=sd(mietspiegel2015$nm)),n=100)
            }
  )
  print(hist)
}


#' @title Funktionen zum Buch
#' @description Erstelle das Histogramm (Abbildung 2.35b) für die
#' Münchner Rück Aktie (Renditen=log returns) plus Kerndichte-Schaetzung
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.34b <- function(){

  require("lattice")
  require("tseries")

  munichre2 <- get.hist.quote(start="2000-01-01", end="2015-06-03",instrument="muv2.de", quote="AdjClose")
  r.munichre2 <- diff(log(munichre2$Adjusted))
  m <- mean(r.munichre2)
  s <- sd(r.munichre2)

  hist <- histogram(data.frame(r.munichre2)$r.munichre2,
            xlab=list("Rendite der Munich RE-Aktie",cex=1.5),
            col="grey90",
            ylab=list("Dichte",cex=1.5),
            type="density",
            scales=list(cex=1.5),
            ylim=c(0,35),
            breaks=
              c(-0.19,-0.14,-0.09,-0.04,0.01,0.06,0.11,0.16,0.21,0.26),
            panel = function(x, ...) {
              panel.histogram(x, ...)
              panel.densityplot(x, col="black",plot.points=FALSE)
              #panel.mathdensity(dmath = dnorm, col = "black",
              #                  args = list(mean=m,sd=s),n=200)
            }

            )
  print(hist)
}


#' @title Funktionen zum Buch
#' @description Erstelle das Histogramm (Abbildung 2.35c) für die
#' Umlaufrenditen plus Kerndichte-Schaetzung
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.34c <- function(){

  require("lattice")

  data(umlaufrenditen, envir=environment())
  hist <- histogram(umlaufrenditen$BBK01.WU0017,
            breaks=c(0,0.5,1,1.5,2,2.5,3,3.5,4,4.5,5,5.5,6,6.5,
                     7,7.5,8,8.5,9,9.5,10,10.5,11,11.5,12),
            type="density",
            col="grey90",
            xlab=list("Umlaufrendite in Prozent",cex=1.5),
            ylab=list("Dichte",cex=1.5),
            scales=list(cex=1.5),
            panel = function(x, ...) {
              panel.histogram(x, ...)
              panel.densityplot(x, col="black",plot.points=FALSE)
            }
  )
  print(hist)
}


#' @title Funktionen zum Buch
#' @description Erstelle Quantile (Beispiel 2.32) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, nur Wohnungen ohne
#' zentrale Warmwasserversorgung
#' @export
#' @param () Keine Parameter
#' @return Liste der benoetigten Werte
#' \item{quantile}{Empirische Quantile}
#' \item{xi}{Geordnete Werte}
#' \item{zi}{NV Quantile}
#' @export
bsp2.29 <- function(){

  data("mietspiegel2015", envir=environment())

  # Alle Wohnungen ohne zentrale Warmwasserversorgung
  nm.ohne.ww <- sort(subset(mietspiegel2015, ww0==1)$nm)
  quantil <- (seq(1:length(nm.ohne.ww))-0.5) / length(nm.ohne.ww)
  z <- qnorm(p=quantil)

  return(list(quantile=quantil, xi=nm.ohne.ww, zi=z))

}

#' @title Funktionen zum Buch
#' @description Erstelle NQ-Plot (Abbildung 2.39) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, nur Wohnungen ohne
#' zentrale Warmwasserversorgung
#' @export
#' @param () Keine Parameter
#' @return Ausgabe in Konsole
#' @export
abb2.38 <- function(){

  data("mietspiegel2015", envir=environment())

  # Alle Wohnungen ohne zentrale Warmwasserversorgung
  nm.ohne.ww <- sort(subset(mietspiegel2015, ww0==1)$nm)

  quantil <- (seq(1:length(nm.ohne.ww))-0.5) / length(nm.ohne.ww)
  z <- qnorm(p=quantil)
  plot(z,nm.ohne.ww,
       xlab="Quantile der Standardnormalverteilung",
       ylab="Nettomiete in Euro")
  abline(a=mean(nm.ohne.ww), b=sd(nm.ohne.ww))

  #return(0)
  #qqnorm(nm.ohne.ww,
  #       xlab="Quantile der Standardnormalverteilung",
  #       ylab="Nettomiete in Euro")
  #qqline(nm.ohne.ww)

}


#' @title Funktionen zum Buch
#' @description Erstelle NQ-Plot (Abbildung 2.40) für die
#' Variable Nettomiete des Münchner Mietspiegels 2015, alle Wohnungen
#' @export
#' @param () Keine Parameter
#' @return Ausgabe in Konsole
#' @export
abb2.39 <- function(){

  data("mietspiegel2015", envir=environment())

  qqnorm(mietspiegel2015$nm,
         xlab="Quantile der Standardnormalverteilung",
         ylab="Nettomiete in Euro",
         main="")
  qqline(mietspiegel2015$nm)
}


#' @title Funktionen zum Buch
#' @description Erstelle den NQ-Plot (Abbildung 2.41) für die
#' Tagesrenditen der BMW-Aktie
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.40 <- function(){
  require("tseries")

  bmw2 <- get.hist.quote(start="2000-01-01", end="2015-06-03", instrument="bmw.de", quote="AdjClose")
  r.bmw2 <- diff(log(bmw2$Adjusted))
  qqnorm(r.bmw2,main="",xlab="Quantile der Standardnormalverteilung",
         ylab="Rendite der BMW-Aktie")
  qqline(r.bmw2)

}


#' @title Funktionen zum Buch
#' @description Berechne Histogramm und Dichtekurven, Abbildung 2.43a
#' Nettomiete in Euro
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.42a <- function(){
  require("lattice")
  # daily
  data("mietspiegel2015", envir=environment())

  hist <- histogram(mietspiegel2015$nm,
            xlab=list("Nettomiete in Euro",cex=1.5),
            col="grey90",
            ylab=list("Dichte",cex=1.5),
            type="density",
            scales=list(cex=1.5),
            breaks=seq(from=0,to=6000,by=100),
            panel = function(x, ...) {
              panel.histogram(x, ...)
              panel.mathdensity(dmath = dnorm, col="black", lty=2,
                                args = list(mean=
                                              mean(mietspiegel2015$nm),
                                            sd=sd(mietspiegel2015$nm)),n=200)
              panel.densityplot(x, lty=1, col="black",plot.points=F)
            }
  )
  print(hist)

}


#' @title Funktionen zum Buch
#' @description Erstelle das Histogramm (Abbildung 2.43b) für die
#' Münchner Rück Aktie (Renditen=log returns) plus NV plot und Kerndichte
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb2.42b <- function(){

  require("lattice")
  require("tseries")

  munichre2 <- get.hist.quote(start="2000-01-01", end="2015-06-03",instrument="muv2.de", quote="AdjClose")
  r.munichre2 <- diff(log(munichre2$Adjusted))
  m <- mean(r.munichre2)
  s <- sd(r.munichre2)

  hist <- histogram(data.frame(r.munichre2)$r.munichre2,
            xlab=list("Rendite der Munich RE-Aktie",cex=1.5),
            col="grey90",
            ylab=list("Dichte",cex=1.5),
            type="density",
            scales=list(cex=1.5),
            ylim=c(0,35),
            breaks=
              #c(-0.19,-0.14,-0.09,-0.04,0.01,0.06,0.11,0.16,0.21,0.26),
              seq(from=-0.25, to=0.25, by=0.01),
            panel = function(x, ...) {
              panel.histogram(x, ...)
              panel.mathdensity(dmath = dnorm, col = "black", lty=2,
                                args = list(mean=m,sd=s),n=200)
              panel.densityplot(x, lty=1, col="black",plot.points=F)
            }
  )
  #plot(density(data.frame(r.munichre2)$r.munichre2))
  print(hist)
}


#' @title Funktionen zum Buch
#' @description Erstelle die Daten zur Arbeitslosigkeit (Tabelle 3.2)
#' @export
#' @return Liste aus table-Objekt und data frame
#' \item{Absolut}{Absolute Häufigkeiten}
createArbeitslosigkeit <- function(){
   ausbildung<- c(rep(1,86), rep(2,170),	rep(3,40), rep(4,28),
                  rep(1,19), rep(2,43),	rep(3,11), rep(4,4),
                  rep(1,18), rep(2,20),	rep(3,5), rep(4,3)
                  )
  ausbildung <- ordered(ausbildung)
  levels(ausbildung) <- c("keine","Lehre","fachspezifisch","Hochschule")

  arbeitslosigkeit <- c(rep(1,324), rep(2,77), rep(3,46))
  arbeitslosigkeit <- ordered(arbeitslosigkeit)
  levels(arbeitslosigkeit) <- c("kurz","mittel","lang")

  h <- table(ausbildung,arbeitslosigkeit)

  return(list(Absolut=h))

}



#' @title Funktionen zum Buch
#' @description Erstelle die Sharedaten (Tabelle 3.3)
#' @export
#' @return Liste aus table-Objekt und data frame
#' \item{Absolut}{Absolute Häufigkeiten}
createSharedaten <- function(){
  mobility<-  c( rep(0,423), rep(1,115),	rep(2,78), rep(3,64), rep(4,45),
                 rep(0,14952), rep(1,2897), rep(2,1147),	rep(3,747), rep(4,349),
                 rep(0,15810),rep(1,4261), rep(2,1637),	rep(3,894), rep(4,324),
                 rep(0,6211),rep(1,3164), rep(2,1463),	rep(3,968), rep(4,288)
  )
  mobility <- ordered(mobility)
  levels(mobility) <- c("0","1","2","3","4")

  bmi.cat <- c(rep(1,725), rep(2,20092), rep(3,22926), rep(4,12094))
  bmi.cat <- ordered(bmi.cat)
  levels(bmi.cat) <- c("<18.5","18.5-24.9","25-29.9",">=30")

  h <- table(mobility, bmi.cat)

  colsums <- colSums(h)

  bedingt <- cbind( h[,1] / colSums(h)[1],
                    h[,2] / colSums(h)[2],
                    h[,3] / colSums(h)[3],
                    h[,4] / colSums(h)[4])

  chisq <- chisq.test(h)

  return(list(Absolut=h, mit.raendern=addmargins(h), Mobi.gegeben.BMI=bedingt,
              chiquadrat=chisq))

}


#' @title Funktionen zum Buch
#' @description Gemeinsame Verteilung fuer die Ausbildungsdaten (vgl. Abbildung 3.1)
#' @export
#' @return Grafik
abb3.1 <- function(){
  h <- createArbeitslosigkeit()
  barplot(h$Absolut, beside=T, ylim=c(0,200),legend=T, args.legend=c(x="topright"))
}



#' @title Funktionen zum Buch
#' @description Streudiagramm zum Mietspiegel (Abbildung 3.5)
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb3.5 <- function(){
  data("mietspiegel2015", envir=environment())
  plot(mietspiegel2015$wfl, mietspiegel2015$nm,
       xlab="Wohnfläche",
       ylab="Nettomiete")
}

#' @title Funktionen zum Buch
#' @description Zweidimensionales Histogramm zum Mietspiegel,
#' Nettomiete gedeckelt bei 2000 Euro, Wohnfläche <= 200qm (Abbildung 3.6)
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb3.6 <- function(){

  par(cex=2/3)
  oldmar <- par("mar")
  #par(mar=c(5,6,4,2)+0.1)
  require(MASS)
  require(epade)
  require(gplots)
  data("mietspiegel2015", envir=environment())

  sub <- subset(mietspiegel2015, wfl<=200 & nm<=2000)
  h <- hist2d(sub$nm, sub$wfl, nbins=c(10,10), show=FALSE)
  beschriftung <- rownames(h$counts)
  rownames(h$counts) <- c(
   "[174.75,357.275]","(357.275,539.8]","","",
   "","","","",
   "","(1817.475,2000]"
  )
  print(rownames(h$counts))

  bar3d.ade(h$counts,xw=18,
            xlab="Wohnfläche",
            zlab="Nettomiete",
            col="white",
            wall=2)
  par(cex=1)
  #par("mar"=oldmar)
}


#' @title Funktionen zum Buch
#' @description Zweidimensionale Kerndichteschätzung zum Mietspiegel,
#' ohne den höchsten Wert für Nettomiete(6000), Abbildung 3.7
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb3.7 <- function(){

  require(MASS)

  par(cex=2/3)
  oldmar <- par("mar")
  par(mar=c(5,6,4,2)+0.1)

  data("mietspiegel2015", envir=environment())

  bkd <- kde2d(mietspiegel2015$wfl,mietspiegel2015$nm, n=100,
               h=c(20,200),
               lims=c(
                 c(min(mietspiegel2015$wfl),200),
                 c(min(mietspiegel2015$nm), 2000)
               ))
  persp(bkd, phi = 20, theta = 30, shade = .1,
        xlab="Wohnfläche",
        ylab="Nettomiete",
        zlab="Dichte f",
        ticktype="detailed",
        expand=0.5)
  par(cex=1)
  par("mar"=oldmar)
}


#' @title Funktionen zum Buch
#' @description Streudiagramme zum Mietspiegel,
#' ohne den höchsten Wert für Nettomiete(6000), Abbildung 3.8
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb3.8 <- function(){

  require(MASS)
  data("mietspiegel2015", envir=environment())
  pairs(data.frame(mietspiegel2015$nm,mietspiegel2015$nmqm,
        mietspiegel2015$wfl,mietspiegel2015$rooms),
        labels=c("Nettomiete","Nettomiete/qm","Wohnfläche","Zimmeranzahl"))

}

#' @title Funktionen zum Buch
#' @description Korrelationen, Beispiele 3.19, 3.22
#' @param () Keine Parameter
#' @return Konsole
#' @export
bsp3.16 <- function(){
  data("mietspiegel2015", envir=environment())
  subdata <- data.frame(mietspiegel2015$nm,
                        mietspiegel2015$wfl,
                        mietspiegel2015$rooms,
                        mietspiegel2015$nmqm)
  print("Pearson")
  print(cor(subdata,method="pearson"), digits=3)
  print("Spearman")
  print(cor(subdata,method="spearman"), digits=3)
  print("Kendall's tau")
  print(cor(subdata,method="kendall"), digits=3)
}


#' @title Funktionen zum Buch
#' @description Regression, Beispiel 3.27, 3.29, Abbildungen 3.16 und 3.18
#' @param () Keine Parameter
#' @return Konsole
#' @export
bsp3.24 <- function(){
  data("mietspiegel2015", envir=environment())
  m1 <- lm(nm~wfl, data=mietspiegel2015)
  print(summary(m1))

  pdf("abb3_16.pdf")
  plot(mietspiegel2015$wfl,mietspiegel2015$nm,
       xlab="Wohnfläche", ylab="Nettomiete")
  abline(a=coefficients(m1)[1], b=coefficients(m1)[2])
  dev.off()

  pdf("abb3_18.pdf")
  plot(m1,which=c(1), sub.caption="", caption="")
  dev.off()

  postscript("abb3_16.ps")
  plot(mietspiegel2015$wfl,mietspiegel2015$nm,
       xlab="Wohnfläche", ylab="Nettomiete")
  abline(a=coefficients(m1)[1], b=coefficients(m1)[2])
  dev.off()

  postscript("abb3_18.ps")
  plot(m1,which=c(1), sub.caption="", caption="")
  dev.off()

  plot(m1, which=c(1), sub.caption="", caption="")

  return(m1)
}

#' @title Funktionen zum Buch
#' @description Regression, Beispiel 3.26 (Tiefschlafdauer), Abbildung 3.15
#' @param () Keine Parameter
#' @return Konsole
#' @export
bsp3.26 <- function(){
  x <- c(0.3, 2.2, 0.5, 0.7, 1.0, 1.8, 3.0, 0.2, 2.3)
  y <- c(5.8, 4.4, 6.5, 5.8, 5.6, 5.0, 4.8, 6.0, 6.1)
  df <- data.frame(x,y)
  #df <- df[order(df[,1]),]
  colnames(df) <- c("Fernsehzeit","Tiefschlafdauer")
  model <- lm(Tiefschlafdauer~Fernsehzeit, data=df)
  X <- c(0, 2.3, 3.5)
  Y <- predict(model, newdata=data.frame(Fernsehzeit=X))
  pdf("abb3_15.pdf")
  par(cex.lab=1.4)
  plot(x,y,xlab="Fernsehzeit", ylab="Tiefschlafdauer",
       xlim=c(0,4), type="p")
  lines(x=X, y=Y)
  #abline(a=coefficients(model)[1], b=coefficients(model)[2],
  #       xlim=c(0,3))
  text(3.5,5,expression(hat(alpha)+hat(beta)*x), cex=1.4)
  lines(x=c(2.3, 2.3), y=c(Y[2],6.1) )
  text(2.6, 5.7, expression(y[i]-hat(y[i])), cex=1.4)
  par(cex.lab=1)
  dev.off()
}



#' @title Funktionen zum Buch
#' @description Regression, Beispiel 12.5, Abbildung 12.6
#' @param () Keine Parameter
#' @return lm
#' @export
abb12.6 <- function(){
  data("mietspiegel2015", envir=environment())
  m1 <- lm(nm~wfl, data=mietspiegel2015)
  print(summary(m1))

  residuals <- resid(m1)
  qqnorm(residuals,
         xlab="Quantile der Standardnormalverteilung",
         ylab="Residuen",
         main="")

  return(m1)
}

#' @title Funktionen zum Buch
#' @description Regression, Beispiel 12.7
#' @param () Keine Parameter
#' @return lm
#' @export
bsp12.7 <- function(){
  data("mietspiegel2015", envir=environment())

  bj.cat <- cut(mietspiegel2015$bj, breaks=c(1900,1919, 1949, 1966, 1978, 1990,2015),
                labels=c("bis 1918", "1919 bis 48", "1949 bis 65", "1966 bis 77", "1978 bis 90",
                         "ab 1990"),
                right=FALSE,dig.lab=4)
  # select 1978 - 1990
  extended.dat <- data.frame(mietspiegel2015, bj.cat)
  subdata <- subset(extended.dat, bj.cat=="1978 bis 90")
  print(nrow(subdata))

  m1 <- lm(log(nm)~wfl + wohngut + wohnbest + badkach0 + kueche,
           data=subdata)
  print(summary(m1))

  return(m1)
}


#' @title Funktionen zum Buch
#' @description Regression, Abbildung 12.7
#' @param () Keine Parameter
#' @return lm
#' @export
abb12.7 <- function(){
  data("mietspiegel2015", envir=environment())

  bj.cat <- cut(mietspiegel2015$bj, breaks=c(1900,1919, 1949, 1966, 1978, 1990,2015),
                labels=c("bis 1918", "1919 bis 48", "1949 bis 65", "1966 bis 77", "1978 bis 90",
                         "ab 1990"),
                right=FALSE,dig.lab=4)
  # select 1978 - 1990
  extended.dat <- data.frame(mietspiegel2015, bj.cat)
  subdata <- subset(extended.dat, bj.cat=="1978 bis 90")
  print(nrow(subdata))

  m1 <- lm(log(nm)~wfl + wohngut + wohnbest + badkach0 + kueche,
           data=subdata)
  print(summary(m1))

  plot(m1, which=c(1), add.smooth=F, sub.caption="", caption="")

  return(m1)
}

#' @title Funktionen zum Buch
#' @description Regression, Abbildung 12.8
#' @param () Keine Parameter
#' @return lm
#' @export
abb12.8 <- function(){
  data("mietspiegel2015", envir=environment())

  bj.cat <- cut(mietspiegel2015$bj, breaks=c(1900,1919, 1949, 1966, 1978, 1990,2015),
                labels=c("bis 1918", "1919 bis 48", "1949 bis 65", "1966 bis 77", "1978 bis 90",
                         "ab 1990"),
                right=FALSE,dig.lab=4)
  # select 1978 - 1990
  extended.dat <- data.frame(mietspiegel2015, bj.cat)
  subdata <- subset(extended.dat, bj.cat=="1978 bis 90")
  print(nrow(subdata))

  m1 <- lm(log(nm)~wfl + wohngut + wohnbest + badkach0 + kueche,
           data=subdata)
  print(summary(m1))

  residuals <- resid(m1)
  qqnorm(residuals,
         xlab="Quantile der Standardnormalverteilung",
         ylab="Residuen",
         main="")

    return(m1)
}

#' @title Funktionen zum Buch
#' @description Regression, Beispiel 12.10, Abbildung 12.10
#' @param () Keine Parameter
#' @return lm
#' @export
abb12.10 <- function(){

  require("splines")
  data("mietspiegel2015", envir=environment())

  m1 <- lm(nm ~ bs(wfl, degree=3), data=mietspiegel2015)
  print(summary(m1))

  plot(mietspiegel2015$wfl,mietspiegel2015$nm,
       xlab="Wohnfläche", ylab="Nettomiete")

  h <- cbind(mietspiegel2015$wfl, predict(m1))
  h <- h[order(h[,1]), ]
  lines(h[,1],h[,2], type="l")

  return(m1)
}

#' @title Funktionen zum Buch
#' @description Regression, Beispiel 12.11, Abbildung 12.11
#' @param () Keine Parameter
#' @return lm
#' @export
abb12.11 <- function(){

  require("splines")

  data("mietspiegel2015", envir=environment())

  bj.cat <- cut(mietspiegel2015$bj, breaks=c(1900,1919, 1949, 1966, 1978, 1990,2015),
                labels=c("bis 1918", "1919 bis 48", "1949 bis 65", "1966 bis 77", "1978 bis 90",
                         "ab 1990"),
                right=FALSE,dig.lab=4)
  # select 1978 - 1990
  extended.dat <- data.frame(mietspiegel2015, bj.cat)
  subdata <- subset(extended.dat, bj.cat=="1978 bis 90")
  print(nrow(subdata))

  m1 <- lm(log(nm)~ bs(wfl, degree=3), data=subdata)
  print(summary(m1))

  plot(subdata$wfl,log(subdata$nm),
       xlab="Wohnfläche", ylab="log(Nettomiete)")
  h <- cbind(subdata$wfl, predict(m1))
  h <- h[order(h[,1]), ]
  lines(h[,1],h[,2], type="l")


  return(m1)
}

#' @title Funktionen zum Buch
#' @description Regression, Aufgabe 12.2
#' @param () Keine Parameter
#' @return lm object
#' @export
aufg12.2 <- function(){
  data("mietspiegel2015", envir=environment())

  subdata <- subset(mietspiegel2015, bj>1984)
  print(nrow(subdata))

  m1 <- lm(log(nm)~wfl + wohngut + wohnbest + badkach0 + kueche,
           data=subdata)
  print(summary(m1))

  return(m1)
}

#' @title Funktionen zum Buch
#' @description Beispiel 11.3, t-Wert
#' @param () Keine Parameter
#' @return t
#' @export
bsp11.3 <- function(){

  data("mietspiegel2015", envir=environment())
  # Stichprobe von 11 Wohnungen
  nmqm <- mietspiegel2015$nmqm[c(303,757,434,1594,
                                 1339,175,622,1824,
                                 2170,669,921)]
  print(nmqm)

  t <- ( mean(nmqm) - 8) / sd(nmqm) * sqrt(11)
  print(t)

  return( list(daten=nmqm, t.wert=t))

}



#' @title Funktionen zum Buch
#' @description chi-quadrat Test, Beispiel 11.6
#' @export
#' @param () Keine Parameter
#' @return Chiquadrat-Anpassungstest
#' @export
bsp11.6 <- function(){

  data("mietspiegel2015", envir=environment())

  bj.cat <- cut(mietspiegel2015$bj, breaks=c(1900,1919, 1949, 1966, 1978, 1990,2015),
                labels=c("bis 1918", "1919 bis 48", "1949 bis 65", "1966 bis 77", "1978 bis 90",
                         "ab 1990"),
                right=FALSE,dig.lab=4)
  wfl.cat <- cut(mietspiegel2015$wfl, breaks=c(0,39,81,121,301),
                 labels=c("bis 38", "39-80", "81-120", "121 und mehr"),
                 right=FALSE,dig.lab=3)

  daten <- data.frame(cbind(mietspiegel2015, bj.cat, wfl.cat))

  subdaten <- subset(daten, wfl.cat=="121 und mehr" |
                       wfl.cat=="81-120")

  m <- mean( subdaten$nm)
  s <- sd(subdaten$nm)
  samplesize <- nrow(subdaten)

  cutpoints <- c(-Inf,400,500,600,700,800,900,1000,
                 1100,1200,1300,1400,1500,1600,1700,
                 1800,1900,2000,2100,2200,Inf
  )

  nmcat <- cut( subdaten$nm, breaks=cutpoints,
                right=FALSE, include.lowest=TRUE)
  numlevels <- length(levels(nmcat))
  degrees <- numlevels - 1 -2

  # expected frequencies from a normal with mean m and standard
  # deviation sd
 p <- vector(mode="numeric", length=numlevels )
  for ( i in 1:(length(cutpoints)-1) ){
    p[i] <- pnorm(q=cutpoints[i+1], mean=m, sd=s) -
            pnorm(q=cutpoints[i], mean=m, sd=s)
  }

  np <- samplesize*p

  h <- as.data.frame(table(nmcat))$Freq

  chisq <- sum ( (h-np)^2/np )

  pval <- 1-pchisq(q=chisq, df=degrees)

  #chisq.test( as.data.frame(table(nmcat))$Freq, p=p )

  newh   <- c(h[1],h[2:17],sum(h[18:20]) )
  newp   <- c(p[1],p[2:17],sum(p[18:20]) )
  newnp <- c(np[1],np[2:17],sum(np[18:20]) )
  newchisq <-  sum ( (newh-newnp)^2/newnp )
  newnumlevels <- length(newh)

  #print(summary(subdaten))
  return(list(m=m,s=s,samplesize=samplesize,
              numlevels=numlevels,
              degrees=degrees,nmcat=nmcat,
              p=p,np=np,
              chisq=chisq,pval=pval,
              newchisq=newchisq,
              newnumlevels=newnumlevels) )

}

#' @title Funktionen zum Buch
#' @description t- und Welch-test, Beispiel 11.7
#' @export
#' @param () Keine Parameter
#' @return t.test, welch.test
#' @export
bsp11.7 <- function(){

  data("mietspiegel2015", envir=environment())

  splitdaten <- split(mietspiegel2015, mietspiegel2015$rooms)

  h <- t.test( splitdaten$'1'$nmqm,splitdaten$'2'$nmqm,
               var.equal=TRUE)

  welch <-  t.test( splitdaten$'1'$nmqm,splitdaten$'2'$nmqm,
                    var.equal=FALSE)

  return(list(t.test=h,welch.test=welch))
}


#' @title Funktionen zum Buch
#' @description Beispiel 11.8 (Wilcoxon-Test)
#' @export
#' @param () Keine Parameter
#' @return Wilcoxon
#' @export
bsp11.8 <- function(){

  data("mietspiegel2015", envir=environment())

  n <- 10
  m <- 9

  splitdaten <- split(mietspiegel2015, mietspiegel2015$rooms)
  fuenf <- splitdaten$'5'$nmqm[c(5,10,15,20,25,30,35,40,45,50)]
  sechs <- splitdaten$'6'$nmqm[c(2,4,6,7,8,10,12,14,16)]

  mf <-mean(fuenf)
  vf <-var(fuenf)
  ms <-mean(sechs)
  vs <-var(sechs)
  k <- (vf/n+vs/m)^2 / ( 1/(n-1)*(vf/n)^2 + 1/(m-1)*(vs/m)^2 )

  t1 <- t.test(fuenf, sechs, var.equal = TRUE)
  t2 <- t.test(fuenf, sechs)
  t3 <- wilcox.test(fuenf,sechs)

  for.wilcox <- data.frame(c(fuenf,sechs), c(rep("X",n),rep("Y",m)))
  colnames(for.wilcox) <- c("Y","Group")
  for.wilcox <- for.wilcox[ order(for.wilcox$Y),]

  return(list(fuenf=fuenf,sechs=sechs,mean5=mf, var5=vf,mean6=ms,var6=vs,
              t.test=t1,welch.test=t2,wilcoxon.test=t3,k=k,
              for.wilcox=for.wilcox))
}


#' @title Funktionen zum Buch
#' @description Erstelle Zeitreihe (Abb. 14.2) für den
#' DAX
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb14.2 <- function(){
  require("tseries")
  require("zoo")
  data("dax_daily")
  d <- read.zoo(dax_daily)
  plot(d, xlab="Zeitraum: 3.1.2000-3.6.2015",ylab="DAX",cex=1.5)

}

#' @title Funktionen zum Buch
#' @description Erstelle Zeitreihe mit LOESS Schaetzung (Abbildung 14.9) für die
#' BMW-Aktie
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
abb14_loess <- function(){
  require("tseries")
  require("zoo")

  bmw2 <- get.hist.quote(start="2000-01-01", end="2015-06-03", instrument="bmw.de",
                         quote="AdjClose")
  plot(bmw2, type="l",
       xlab="Zeitraum: 3.1.2000-3.6.2015", ylab="Tageskurse der BMW-Aktie")
  index <- 1:length(bmw2)
  print(index)
  lo <- loess(bmw2$Adjusted~index)
  print(predict(lo))
  lines(index(bmw2), predict(lo))
}

#' @title Funktionen zum Buch
#' @description Abbildung 9.1
#' @param () Keine Parameter
#' @return Konsole
#' @export
abb9.1 <- function(){

  pdf("abb9_1.pdf")
  n1 <- 2
  n2 <- 10
  eps <- 1
  sigma <- 1
  xq.n1 <- 1/sqrt(n1)
  xq.n2 <- 1/sqrt(n2)
  curve(dnorm(x,mean=0,sd=xq.n2),
        from=-3*eps, to=3*eps,
        xaxt='n',xlab="",yaxt="n",ylab="", ylim=c(0,1.35))
  curve(dnorm(x,mean=0,sd=xq.n1),from=-3*eps, to=3*eps, add=T)
  mtext(at=c(0), side=1, padj=1,expression(paste(mu)))
  mtext(at=c(eps), side=1, padj=1,expression(paste(mu-epsilon)))
  mtext(at=c(-eps), side=1, padj=1,expression(paste(mu+epsilon)))
  axis(1, at=c(-eps,0,eps), labels=F)
  abline(v=-eps, lty=2)
  abline(v=eps, lty=2)
  text(0,0.6, expression(paste(n[1],"=",2)))
  text(0,1.3, expression(paste(n[2],"=",10)))
  par(cex.lab=1)
  dev.off()
}



#' @title Funktionen zum Buch
#' @description Erstelle Plots
#' @export
#' @param () Keine Parameter
#' @return Grafik
#' @export
createPlots <- function(){
  require("R.devices")
  filenames <- c("1_1", "1_2","1_3","2_1","2_2","2_3","2_4","2_5",
                 "2_6","2_7","2_8","2_9","2_10","2_11","2_12",
                 "2_13","2_14","2_15","2_17","2_19","2_20","2_21",
                 "2_22","2_23","2_25","2_26","2_28","2_30",
                 "2_32a", "2_32b", "2_32c","2_32d", "2_32e",
                 "2_34a",
                 "2_34b","2_34c","2_38","2_39","2_40","2_42a","2_42b",
                 "3_1","3_5","3_6","3_7","3_8", "12_6","12_7","12_8",
                 "12_10", "12_11",
                 "14_2")
  funcnames <- c("1.1", "1.2","1.3","2.1","2.2","2.3","2.4","2.5",
                 "2.6","2.7","2.8","2.9","2.10","2.11","2.12",
                 "2.13","2.14","2.15","2.17","2.19","2.20","2.21",
                 "2.22","2.23","2.25","2.26","2.28","2.30",
                 "2.32a", "2.32b", "2.32c","2.32d", "2.32e",
                 "2.34a",
                 "2.34b","2.34c","2.38","2.39","2.40","2.42a","2.42b",
                 "3.1","3.5","3.6","3.7","3.8","12.6", "12.7","12.8",
                 "12.10", "12.11",
                 "14.2")
  n <- length(filenames)
  ext <- c(".pdf", ".ps")
  for (i in 1:n){
    for (j in 1:2){
      f <- paste("abb",filenames[i],ext[j], sep="")
      if (j==1){
        pdf(f)
        #devEval("pdf", name=f, aspectRatio=0.7, {
        par(cex=1.5)
        eval(parse(text=paste("abb",funcnames[i],"()",sep="")))
        par(cex=1)
        #})
        dev.off()
      }
      else {
        postscript(f)
        par(cex=1.5)
        eval(parse(text=paste("abb",funcnames[i],"()",sep="")))
        par(cex=1)
        dev.off()
      }
    }
  }
}


